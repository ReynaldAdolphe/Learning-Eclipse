package com.mysecondproject.model;

public class Student {

}
