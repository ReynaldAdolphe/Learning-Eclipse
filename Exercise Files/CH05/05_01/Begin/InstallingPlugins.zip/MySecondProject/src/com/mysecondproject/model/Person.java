/**
 * 
 */
package com.mysecondproject.model;

/**
 * @author Reynald Adolphe
 *
 */
public interface Person {

}
