
public class RiseAndShine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		startProcess();		
	}

	private static void startProcess() {
		System.out.println("Rise & Shine, Everyone!!");
		DateTime.GetDateAndTime();
		
		int year_2080 = 2080;
		int year_2085 = 2080 + 5;
		System.out.println("Just doing a little calulation...");
		System.out.println("Five years after " 
					+ year_2080 + ", it will be the year " + year_2085);
		System.out.println("A movie ticket will cost: $573"
					+ " even on discount Tuesday!");
	}

}
